### 天翼网盘和阿里云盘签到脚本

感谢 https://github.com/wes-lin/Cloud189Checkin 

```linux
git clone https://github.com/zhlhlf/drive_checkin --depth=1

cd Cloud189Checkin && npm install
export tyy="userphone1 password1 userphone2 password2"
export alirefreshToeknArry="refresh_token1 refresh_token2"
npm start
```

